﻿using System;
using System.Linq;
using System.Configuration;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.Security;
using System.Web.UI.WebControls;
using System.IO;

namespace CsharpDEMO
{
    public partial class Receive : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            String key = ConfigurationManager.AppSettings["userkey"];//配置文件密钥
                                                                     //返回参数
            String orderid = Request["orderid"];//返回订单号
            String opstate = Request["opstate"];//返回处理结果
            String ovalue = Request["ovalue"];//返回实际充值金额
            String sign = Request["sign"];//返回签名
            String sysorderid = Request["sysorderid"];//亿付录入时产生流水号。
            String completiontime = Request["completiontime"];//亿付处理时间。
            String attach = Request["attach"];//上行附加信息
            String msg = Request["msg"];//亿付返回订单处理消息

            String param = String.Format("orderid={0}&opstate={1}&ovalue={2}{3}", orderid, opstate, ovalue, key);//组织参数
                                                                                                                 //比对签名是否有效
            if (sign.Equals(FormsAuthentication.HashPasswordForStoringInConfigFile(param, "MD5").ToLower()))
            {
                //执行操作方法
                if (opstate.Equals("0") || opstate.Equals("-3"))
                {
                    //操作流程成功的情况
                }
                else if (opstate.Equals("-1"))
                {
                    //卡号密码错误
                }
                else if (opstate.Equals("-2"))
                {
                    //卡实际面值和提交时面值不符，卡内实际面值未使用
                }
                else if (opstate.Equals("-4"))
                {
                    //卡在提交之前已经被使用
                }
                else if (opstate.Equals("-5"))
                {
                    //失败，原因请查看msg
                }
                Response.Write("opstate="+ opstate);//修改过程请勿删除，此处为验证必须的返回值
            }
            else
            {
                //签名无效
            }
        }

        protected void pageWrite(string str)
        {

            str = str + "%%%%%%%%%%%%";
            FileStream fs = File.Open("D:\\Notify.txt", FileMode.Append, FileAccess.Write);
            //获得字节数组
            byte[] data = System.Text.Encoding.Default.GetBytes(str);
            //开始写入
            fs.Write(data, 0, data.Length);
            //清空缓冲区、关闭流
            fs.Flush();
            fs.Close();
        }
    }
}