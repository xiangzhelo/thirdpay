<?php
require_once("eka/init.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>�ڸ�֧����ʾ</title>
<link rel="stylesheet" type="text/css" href="style/ekapay.css">
<script language="javascript" src="js/jquery.js"></script>
<script language="javascript" src="js/pay.js"></script>
</head>
<body>
<center>

<?php
$html	 = '<form method="post" action="pay_go.php"  name="pay" id="pay">';
$html	.= '<div class="pay_base_info">';
$html	.= '<table class="form">';
$html	.= '<tbody>';
$html	.= '<tr class="title">';
$html	.= '	<td colspan="2"><img src="images/jk_logo.gif" /><br/>phpeka demo 1.0 <br/>�ڸ��ӿڰ汾:v2.6<br/>����֧���汾:v1.2</td>';
$html	.= '</tr>';
$html	.= '<tr>';
$html	.= '	<td class="label">֧�����:</td>';
$html	.= '	<td class="content">';
$html	.= '		<input type="text" name="amount" id="amount"  value="20"/>';
$html	.= '	</td>';
$html	.= '</tr>';
$html	.= '<tr>';
$html	.= '	<td class="label">֧����ʽ:</td>';
$html	.= '	<td class="content">';
$html	.= '		<input type="radio" name="payType" id="payType_bank" class="payType" value="bank" checked="checked"><label for="payType_bank">����֧��</label>';
$html	.= '	</td>';
$html	.= '</tr>';


//��������
$html	.= '<tr class="payTypeBank">';
$html	.= '	<td colspan="2">';
$html	.= '	<div class="bankTypeDiv">';
foreach($eka_banktype as $bank){
	$bankTypeRadioId	= 'bankType_' . $bank['code'];
	$html	.= '<span class="bankType">';
	$html	.= '<input type="radio"  class="bankType" name="bankType" id="'.$bankTypeRadioId.'" value="'.$bank['code'].'">';
	$html	.= '<label for="'. $bankTypeRadioId .'">'.$bank['name'].'</label>';
	$html	.= '</span>';
}
$html	.= '	<div>';
$html	.= '	</td>';

$html	.= '</tr>';

$html	.= '<tr class="foot">';
$html	.= '	<td colspan="2"><input type="submit" value="ȷ��֧�� >>" id="submit" name="submit" /></td>';
$html	.= '</tr>';
$html	.= '</tbody>';
$html	.= '</table>';
$html	.= '</form>';
echo($html);
?>
</center>	
</body>
</html>
