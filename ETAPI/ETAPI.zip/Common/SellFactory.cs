﻿using System;
using System.Globalization;
using System.Text;
using System.Web;
using viviapi.BLL.Supplier;
using viviapi.ETAPI.Tenpay;
using viviapi.Model;
using viviapi.Model.supplier;

namespace viviapi.ETAPI.Common
{
    /// <summary>
    /// 
    /// </summary>
    public class SellFactory
    {
        #region OnlineBankPay
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="userkey"></param>
        /// <param name="suppid"></param>
        /// <param name="orderid"></param>
        /// <param name="orderAmt"></param>
        /// <param name="bankcode"></param>
        /// <param name="jump"></param>
        public static void OnlineBankPay(int userid, string userkey, int suppid, string orderid, decimal orderAmt, string bankcode, bool jump)
        {
            SupplierInfo suppInfo = Factory.GetCacheModel(suppid);
            if (suppInfo == null)
            {
                HttpContext.Current.Response.Write("not find supplier object");
                HttpContext.Current.Response.End();
            }

            string payForm = string.Empty;

            bool isdcode = (bankcode == "1003") || (bankcode == "1004");

            if (isdcode == false)
            {
                if (jump == false)
                {
                    payForm = GetPayForm(suppid, orderid,
                        orderAmt, bankcode, true);
                }
                else
                {
                    payForm = GetJumpForm(userid, userkey, suppid, orderid,
                        orderAmt, bankcode);
                }
            }
            else
            {
                if (bankcode == "1003" || bankcode == "1004")//
                {
                    payForm = GetDCodeForm(userid
                        , userkey
                        , suppid
                        , orderid
                        , orderAmt
                        , bankcode);
                }
            }


            if (string.IsNullOrEmpty(payForm))
                payForm = "error";

            //viviLib.Logging.LogHelper.Write(payForm);

            HttpContext.Current.Response.Write(payForm);

        }

        #endregion

        #region GetPayFrom
        /// <summary>
        /// 
        /// </summary>
        /// <param name="suppid"></param>
        /// <param name="orderid"></param>
        /// <param name="orderAmt"></param>
        /// <param name="bankcode"></param>
        /// <param name="autosumit"></param>
        /// <returns></returns>
        public static string GetPayForm(int suppid, string orderid, decimal orderAmt, string bankcode, bool autosumit)
        {
            string payForm = string.Empty;

            switch (suppid)
            {
                case (int)SupplierCode.Alipay:
                    if (bankcode == "101")
                    {
                        var alipay = new Alipay.AliPay(); //直连
                        payForm = alipay.GetPayForm(orderid, orderAmt, autosumit);
                    }
                    else
                    {
                        var malipay = new Alipay.AliPayMApi(); //直连
                        payForm = malipay.GetPayForm(orderid, orderAmt, bankcode, autosumit);
                    }
                    break;

                case (int)SupplierCode.Tenpay:
                    {
                        var tenpay = new TenPayRMB();
                        payForm = tenpay.GetPayForm(orderid, orderAmt, bankcode, autosumit, HttpContext.Current);
                    }
                    break;

                case (int)SupplierCode.YeePay:
                    {
                        var yeepay = new YeePay.RMB();
                        payForm = yeepay.GetPayForm(orderid, orderAmt, bankcode, autosumit);
                    }
                    break;

                case (int)SupplierCode.Baofoo:
                    {
                        var api = new Baofoo.Bank();
                        payForm = api.PayBank(orderid, orderAmt, bankcode, autosumit);
                    }
                    break;

                case (int)SupplierCode.Gopay:
                    {
                        var api = new Gopay.Bank();
                        payForm = api.PayBank(orderid, orderAmt, bankcode, autosumit);
                    }
                    break;

                case (int)SupplierCode.Ebatong:
                    {
                        var api = new Ebatong.Bank();
                        payForm = api.PayBank(orderid, orderAmt, bankcode, autosumit);
                    }
                    break;

                case (int)SupplierCode.Dinpay:
                    {
                        var api = new Dinpay.Bank();
                        payForm = api.PayBank(orderid, orderAmt, bankcode, autosumit);
                    }
                    break;

                case (int)SupplierCode.IPS:
                    {
                        var api = new IPS.Bank();
                        payForm = api.PayBank(orderid, orderAmt, bankcode, autosumit);
                    }
                    break;
                case (int)SupplierCode.Ecpss:
                    {
                        var api = new Ecpss.Bank();
                        payForm = api.GetPayForm(orderid, orderAmt, bankcode, autosumit);
                    }
                    break;
                case (int)SupplierCode.TaoShang:
                    {
                        var api = new TaoShang.Bank();
                        payForm = api.GetPayForm(orderid, orderAmt, bankcode, autosumit);
                    }
                    break;
            }

            return payForm;
        }

        #endregion

        #region GetJumpForm
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="userkey"></param>
        /// <param name="suppid"></param>
        /// <param name="orderid"></param>
        /// <param name="orderAmt"></param>
        /// <param name="bankcode"></param>
        /// <returns></returns>
        public static string GetJumpForm(int userid, string userkey, int suppid, string orderid, decimal orderAmt, string bankcode)
        {
            string form_url = "/gotopay.aspx";

            DateTime time = DateTime.Now;

            string postForm = "<form name=\"payform\" id=\"payform\" method=\"post\" action=\"" + form_url + "\">";

            string sign = string.Format("userid={0}&suppid={1}&orderid={2}&orderAmt={3}&bankcode={4}&time={5}{6}"
                , userid
                , suppid
                , orderid
                , orderAmt
                , bankcode
                , time
                , userkey);

            sign = viviLib.Security.Cryptography.MD5(sign);

            postForm += "<input type=\"hidden\" name=\"userid\" value=\"" + userid + "\" />";
            postForm += "<input type=\"hidden\" name=\"suppid\" value=\"" + suppid + "\" />";
            postForm += "<input type=\"hidden\" name=\"orderid\" value=\"" + orderid + "\" />";
            postForm += "<input type=\"hidden\" name=\"orderAmt\" value=\"" + orderAmt + "\" />";
            postForm += "<input type=\"hidden\" name=\"bankcode\" value=\"" + bankcode + "\" />";
            postForm += "<input type=\"hidden\" name=\"time\" value=\"" + time + "\" />";
            postForm += "<input type=\"hidden\" name=\"sign\" value=\"" + sign + "\" />";
            postForm += "</form>";

            postForm += ("<script type=\"text/javascript\" language=\"javascript\">function go(){ var _form = document.forms['payform']; _form.submit();};setTimeout(function(){go()},100);</script>");


            return postForm;
        }
        #endregion

        #region GetDCodeForm
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="userkey"></param>
        /// <param name="suppid"></param>
        /// <param name="orderid"></param>
        /// <param name="orderAmt"></param>
        /// <param name="bankcode"></param>
        /// <returns></returns>
        public static string GetDCodeForm(int userid, string userkey, int suppid, string orderid, decimal orderAmt, string bankcode)
        {
            string form_url = "/AliDCode.aspx";
            if (bankcode == "1004")
            {
                form_url = "/WeCode.aspx";
            }

            DateTime time = DateTime.Now;

            string postForm = "<form name=\"payform\" id=\"payform\" method=\"get\" action=\"" + form_url + "\">";

            string sign = string.Format("userid={0}&suppid={1}&orderid={2}&orderAmt={3}&bankcode={4}&time={5}{6}"
                , userid
                , suppid
                , orderid
                , orderAmt
                , bankcode
                , time
                , userkey);

            sign = viviLib.Security.Cryptography.MD5(sign);

            postForm += "<input type=\"hidden\" name=\"userid\" value=\"" + userid + "\" />";
            postForm += "<input type=\"hidden\" name=\"suppid\" value=\"" + suppid + "\" />";
            postForm += "<input type=\"hidden\" name=\"orderid\" value=\"" + orderid + "\" />";
            postForm += "<input type=\"hidden\" name=\"orderAmt\" value=\"" + orderAmt + "\" />";
            postForm += "<input type=\"hidden\" name=\"bankcode\" value=\"" + bankcode + "\" />";
            postForm += "<input type=\"hidden\" name=\"time\" value=\"" + time + "\" />";
            postForm += "<input type=\"hidden\" name=\"sign\" value=\"" + sign + "\" />";
            postForm += "</form>";

            postForm += ("<script type=\"text/javascript\" language=\"javascript\">function go(){ var _form = document.forms['payform']; _form.submit();};setTimeout(function(){go()},100);</script>");


            return postForm;
        }
        #endregion

        #region ReqDistribution
        /// <summary>
        /// 
        /// </summary>
        /// <param name="info"></param>
        public static void ReqDistribution(Model.Finance.WithdrawSuppTranLog info)
        {
            //bool result = false;
            //if (info.suppid == 100)
            //{
            //    tenpay.distribution.gw api = new viviapi.ETAPI.tenpay.distribution.gw();
            //    result = api.DoTrans(info);
            //}
            //else if (info.suppid == 1004)
            //{
            //    //Ebatong.distribution.gw api = new viviapi.ETAPI.Ebatong.distribution.gw();
            //    //result = api.DoTrans(info);
            //}
        }
        #endregion
    }
}
