﻿using viviapi.BLL.Supplier;
using viviapi.Model;
using viviapi.SysConfig;
using viviLib.Logging;

namespace viviapi.ETAPI.Common
{
    /// <summary>
    /// 
    /// </summary>
    public class ETAPIBase
    {
        public SupplierInfo SuppInfo = null;

        public ETAPIBase(int suppcode)
        {
            SuppInfo = Factory.GetCacheModel(suppcode);
        }

        public string SuppAccount
        {
            get
            {
                return SuppInfo.puserid;
            }
        }

        public string SuppKey
        {
            get
            {
                return SuppInfo.puserkey;
            }
        }

        public string SuppUserName
        {
            get
            {
                return SuppInfo.pusername;
            }
        }

        public string PostCardUrl
        {
            get
            {
                return SuppInfo.postCardUrl;
            }
        }

        public string PostBankUrl
        {
            get
            {
                return SuppInfo.postBankUrl;
            }
        }

        public string SiteDomain
        {
            get
            {
                string gatewayUrl = RuntimeSetting.GatewayUrl;

                if (string.IsNullOrEmpty(gatewayUrl))
                {
                    var webinfo = BLL.WebInfoFactory.CurrentWebInfo;

                    if (webinfo != null)
                    {
                        gatewayUrl = webinfo.PayUrl;
                    }
                }

                return gatewayUrl;
            }
        }

        /// <summary>
        /// 是否记录同步日志
        /// </summary>
        public bool SynsSummitLog
        {
            get
            {
                return SuppInfo.SynsSummitLog;
            }
        }

        public void SynsSummitLogger(string message)
        {
            if (SynsSummitLog)
            {
                LogWrite(message);
            }
        }

        public void AsynsRetLogger(string message)
        {
            if (SuppInfo.AsynsRetLog)
            {
                LogWrite(message);
            }
        }

        public void LogWrite(string message)
        {
            LogHelper.Info("ETAPILogger", message);
        }
    }
}
